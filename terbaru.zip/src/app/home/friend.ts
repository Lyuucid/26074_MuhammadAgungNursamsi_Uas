export class Friend {
    key: string;
    uid: string;
    email: string;
    constructor(
        uid: string,
        key: string,
        user: string
    ){}
}