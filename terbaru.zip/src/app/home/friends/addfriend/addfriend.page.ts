import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addfriend',
  templateUrl: './addfriend.page.html',
  styleUrls: ['./addfriend.page.scss'],
})
export class AddfriendPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
